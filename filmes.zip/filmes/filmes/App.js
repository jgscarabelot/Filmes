import SplashScreen from '../App/splashscreen';

export default function App() {
  return (
    <SplashScreen/>
  );
}